import os
os.system(pdf2txt.py -o test.txt -t tag MIvsKKR.pdf)