############################STEPS TO INSTALL PDFMINER PACKAGE FOR PDF TO TXT CONVERTOR########################################
# 1). First unzip the tar file pdfminer-20140328.tar
# 2). Then use "cd pdfminer-20140328" command to go inside the pdfminer-20140328 directory
# 3). Then run this given script it will install the PdfMiner Package on to your system

import os
os.system(python setup.py install)